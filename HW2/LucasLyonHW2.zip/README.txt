Instructions:

Key inputs:

Esc = exit the program

R = reset

Q = increase the Y rotation variable
W = decrease the Y rotation variable

A = increase the X rotation variable
S = decrease the X rotation variable

Z = increase the Z rotation variable
X = decrease the Z rotation variable

1 = increase the s Lorenz variable
2 = decrease the s Lorenz variable

3 = increase the r Lorenz variable
4 = decrease the r Lorenz variable

5 = increase the b Lorenz variable
6 = decrease the b Lorenz variable


The program draws the Lorenz attractor from start to finish with 100,000 points.

The assignment took me 5.5 hours to complete.